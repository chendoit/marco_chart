# pip install playwright==1.43.0 loguru
# 單檔版：給朋友複製執行用。請將帳密改成自己的，勿把含真實密碼的檔案公開上傳。
# [時間戳] 寫入 pkl 的時間與原專案規範一致（fromtimestamp 對齊 MacroMicro series）。
# ----------------------------------------------------------------------------
# 請在下方填入 MacroMicro 登入資訊
# ----------------------------------------------------------------------------
MACROMICRO_ID = "ughv2md3@mangschool.life"  # 例：your@email.com
MACROMICRO_PASSWORD = "Guru2025@"
MACROMICRO_LOGIN_URL = "https://www.macromicro.me/login"
# 輸出目錄（可改）
OUTPUT_DIR = r".\data"
# 若 stealth.min.js 與本檔同一目錄則會自動載入；沒有該檔會略過並以 log 提示
# ----------------------------------------------------------------------------

import base64
import json
import os
import pickle
import re
from datetime import datetime, timedelta

from loguru import logger
from playwright.sync_api import sync_playwright
from urllib.parse import urlparse

# Configure logger（與專案慣例類似；可改路徑或移除）
os.makedirs("./logs", exist_ok=True)
logger.add("./logs/{time:YYYY-MM-DD}.log", enqueue=True)

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_STEALTH_JS = os.path.join(_SCRIPT_DIR, "stealth.min.js")

def save_to_pickle(data, filename):
    with open(filename, "wb") as f:
        pickle.dump(data, f)
    logger.info(f"Data saved to {filename}")


def extract_data_from_script(html):
    script_regex = r"<script[^>]*>(.*?)</script>"
    matches = re.findall(script_regex, html, re.DOTALL)

    for match in matches:
        if "isViewable" in match:
            logger.info("Target script found, extracting data...")
            base64_regex = r'JSON\.parse\(atob\(\"(.*?)\"\)\)}]}\)}setTimeout'
            base64_match = re.search(base64_regex, match)

            if base64_match:
                base64_data = base64_match.group(1)
                logger.info(f"Extracted base64 data: {base64_data[:50]}...")
                decoded_bytes = base64.b64decode(base64_data)
                decoded_string = decoded_bytes.decode("utf-8")
                data = json.loads(decoded_string)

                results = []
                for item in data:
                    try:
                        timestamp = item[0] / 1000
                        if timestamp >= 0:
                            datetime_object = datetime.fromtimestamp(timestamp)
                        else:
                            epoch = datetime(1970, 1, 1)
                            datetime_object = (epoch + timedelta(seconds=timestamp)).replace(hour=8)
                        results.append([datetime_object, item[1]])
                    except Exception as e:
                        logger.error(f"Error processing item {item}: {e}")
                        continue
                return results

    logger.warning("No target script or base64 data found.")
    return None


def series_label_from_url(url: str) -> str:
    match = re.search(r"/series/(\d+)/([\w-]+)", url)
    if match:
        return f"{match.group(1)} {match.group(2)}"
    return url if len(url) <= 160 else url[:157] + "..."


def process_url(page, url, output_dir):
    try:
        logger.info(f"Fetching data for URL: {url}")
        page.goto(url)
        page.wait_for_timeout(3000)
        html = page.content()
        data = extract_data_from_script(html)
        if data:
            match = re.search(r"/series/(\d+)/([\w-]+)", url)
            if match:
                series_id = match.group(1)
                title = match.group(2)
                print(f"series_id: {series_id}, title: {title}")
                os.makedirs(output_dir, exist_ok=True)
                output_file = os.path.join(output_dir, f"series_{series_id}.pkl")
                pickle_data = {"title": title, "data": data}
                save_to_pickle(pickle_data, output_file)
                print(f"Data saved to {output_file}")
                return True
            logger.warning(f"URL format does not match: {url}")
            return False
        logger.warning(f"No data extracted from URL: {url}")
        return False
    except Exception as e:
        logger.error(f"Error processing URL {url}: {e}")
        return False


def _find_login_form(page):
    forms = page.locator("form")
    for i in range(forms.count()):
        f = forms.nth(i)
        if f.locator('input[type="password"]').count() != 1:
            continue
        if f.locator('input[type="email"], input[name="email"], input[autocomplete="username"]').count() < 1:
            continue
        return f
    return None


def _ensure_macromicro_session_impl(page):
    uid = (MACROMICRO_ID or "").strip()
    pwd = (MACROMICRO_PASSWORD or "").strip()
    if not uid or not pwd:
        raise RuntimeError("請在檔案頂端設定 MACROMICRO_ID 與 MACROMICRO_PASSWORD")

    login_url = (MACROMICRO_LOGIN_URL or "https://www.macromicro.me/login").strip()
    logger.info("MacroMicro: 前往登入頁")
    page.goto(login_url, wait_until="domcontentloaded", timeout=120000)
    page.wait_for_timeout(2500)

    try:
        tab = page.get_by_role("tab", name="登入")
        if tab.count() > 0:
            tab.first.click(timeout=8000)
            page.wait_for_timeout(800)
    except Exception as e:
        logger.debug(f"MacroMicro: 無法或未找到「登入」分頁: {e}")

    login_form = _find_login_form(page)
    if login_form is not None:
        email_in = login_form.locator(
            'input[type="email"], input[name="email"], input[autocomplete="username"]'
        ).first
        email_in.fill(uid)
        login_form.locator('input[type="password"]').fill(pwd)
        btn = login_form.get_by_role("button", name=re.compile("登入"))
        if btn.count() == 0:
            btn = login_form.locator('button[type="submit"]')
        if btn.count() == 0:
            btn = login_form.locator('input[type="submit"]')
        btn.first.click(timeout=15000)
    else:
        if page.locator('input[type="email"]').count() == 0:
            raise RuntimeError(
                "MacroMicro 登入頁找不到 Email 表單（可能被 Cloudflare 擋下，請改 headless=False 或手動通過驗證）"
            )
        page.locator('input[type="email"]').first.fill(uid)
        page.locator('input[type="password"]').first.fill(pwd)
        page.get_by_role("button", name=re.compile("^登入$")).first.click(timeout=15000)

    page.wait_for_load_state("domcontentloaded")
    page.wait_for_timeout(3500)
    path = urlparse(page.url).path.rstrip("/") or "/"
    if path == "/login":
        raise RuntimeError("MacroMicro 登入失敗（仍停留在登入頁，請檢查帳密）")

    logger.info("MacroMicro: 登入完成")


def ensure_macromicro_session(page):
    """登入；失敗時直接拋出例外（此單檔版不含 LINE 通知）。"""
    _ensure_macromicro_session_impl(page)


def _attach_stealth(page):
    if os.path.isfile(_STEALTH_JS):
        page.add_init_script(path=_STEALTH_JS)
    else:
        logger.warning(f"未找到 stealth.min.js（預期路徑：{_STEALTH_JS}），將略過反偵測腳本")


def fetch_data_from_urls(urls, output_dir=None):
    if output_dir is None:
        output_dir = OUTPUT_DIR
    os.makedirs(output_dir, exist_ok=True)

    with sync_playwright() as playwright:
        browser_args = ["--disable-blink-features=AutomationControlled"]
        browser = playwright.chromium.launch(headless=False, args=browser_args)
        page = browser.new_page()
        _attach_stealth(page)
        page.set_viewport_size({"width": 1024, "height": 768})

        ensure_macromicro_session(page)

        failures: list[str] = []
        for url in urls:
            success = process_url(page, url, output_dir)
            if not success:
                logger.warning(f"Retrying URL {url} with a new browser instance...")
                browser.close()
                browser = playwright.chromium.launch(headless=False, args=browser_args)
                page = browser.new_page()
                _attach_stealth(page)
                page.set_viewport_size({"width": 1024, "height": 768})
                ensure_macromicro_session(page)
                success = process_url(page, url, output_dir)
                if not success:
                    logger.error(f"Failed to process URL {url} after retry.")
                    label = series_label_from_url(url)
                    failures.append(f"{label}\n{url}")

        browser.close()

        if failures:
            body = "\n\n".join(failures)
            logger.warning(f"[抓取失敗 {len(failures)} 筆]\n{body}")


# 僅保留一個範例連結；可自行複製贴上更多 /series/... URL
URL_LIST = [
    "https://www.macromicro.me/series/2/sp500",
]


if __name__ == "__main__":
    fetch_data_from_urls(URL_LIST, OUTPUT_DIR)
